# cdnweb-ui Frontend Application

This is a simple Node.js application created for EX288 practice.

## Application

Framework:

- Node.js
- Express

Application Port:
8080


Environment Variable:
BACKEND_URL: https://cdnweb-be-tiger-db.ocp4.example.com/
