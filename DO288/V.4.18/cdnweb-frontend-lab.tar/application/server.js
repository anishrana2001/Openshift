const express = require("express");

const app = express();

const PORT = process.env.PORT || 8080;

const BACKEND_URL =
    process.env.BACKEND_URL ||
    "https://cdnweb-be-tiger-db.apps.docdn-v44.example.com/";

app.get("/", (req, res) => {

    res.send(`
    <html>
      <head>
        <title>cdnweb-ui</title>
      </head>

      <body>

        <h1>cdnweb frontend application</h1>

        <h3>OpenShift EX288 Practice Lab</h3>

        <p>
          Backend URL:
          ${BACKEND_URL}
        </p>

      </body>
    </html>
    `);

});


app.listen(PORT, () => {

    console.log(
        `cdnweb-ui application running on port ${PORT}`
    );

});
