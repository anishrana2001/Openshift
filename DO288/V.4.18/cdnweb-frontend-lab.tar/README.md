# EX288 cdnweb Frontend Application Lab

## Purpose

This package provides the application source and OpenShift templates required for the EX288 practice task.

## Student Workflow

1. Extract the tar file.
2. Push application source to Git repository.
3. Modify OpenShift templates.
4. Process templates.
5. Build application.
6. Deploy application.


## Build Strategy

This lab uses:
Source-to-Image (S2I) 


No Dockerfile is required.


## Application

Technology:

- Node.js
- Express


## OpenShift Resources

Created resources:

- ImageStream
- BuildConfig
- Deployment
- Service
- Route
