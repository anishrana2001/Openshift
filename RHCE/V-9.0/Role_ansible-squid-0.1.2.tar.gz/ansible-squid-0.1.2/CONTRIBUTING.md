# Contributing to ansible-squid

## Table Of Contents

[Code of Conduct](#code-of-conduct)

## Code of Conduct

This project and everyone participating in it is governed by the [ansible-squid Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to [mrlesmithjr@gmail.com](mailto:mrlesmithjr@gmail.com).
