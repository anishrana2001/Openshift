# Ansible Collection - mwadman.azure_roles

Documentation for each role is included in the role directory.
